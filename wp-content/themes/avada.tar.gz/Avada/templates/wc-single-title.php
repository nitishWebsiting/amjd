<?php
/**
 * Single product title.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       http://theme-fusion.com
 * @package    Avada
 * @subpackage Core
 * @since      5.1.0
 */

?>
<h2 itemprop="name" class="product_title entry-title"><?php the_title(); ?></h2>
